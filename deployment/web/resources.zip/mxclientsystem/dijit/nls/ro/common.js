//>>built
define("dijit/nls/ro/common",({buttonOk:"OK",buttonCancel:"Anulare",buttonSave:"Salvare",itemClose:"Închidere"}));
