//>>built
define("dijit/form/nls/bg/Textarea",({iframeEditTitle:"зона за редактиране",iframeFocusTitle:"рамка на зоната за редактиране"}));
